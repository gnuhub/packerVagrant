default[:os][:startup]       = "/etc/init.d"
default[:tdiNode][:hostname]       = "REUXGBLS291"